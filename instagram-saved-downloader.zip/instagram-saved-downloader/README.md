# Instagram Saved Downloader (Chrome extension)

Downloads the posts you've saved on Instagram into one folder per collection, and remembers what it has already downloaded so each sync only fetches new posts.

## Install

1. Open `chrome://extensions` in Chrome.
2. Turn on **Developer mode** (top right).
3. Click **Load unpacked** and choose this `instagram-saved-downloader` folder.
4. Pin the extension (puzzle-piece icon → pin) so the icon is easy to reach.
5. Make sure you're logged in to instagram.com in the same Chrome profile.

## Use

Click the icon → **Sync now**. Files go to:

```
Downloads/
  Instagram Saved/
    <Collection name>/
      2025-03-14_someuser_DAbC123xyz.jpg
      2025-03-14_otheruser_DXyZ987abc_01.jpg   ← carousel posts get _01, _02, …
      2025-03-14_otheruser_DXyZ987abc_02.mp4
    Unsorted/                                  ← saved posts that aren't in any collection
```

- **Sync automatically once a day** runs a sync about every 24 hours while Chrome is open. If Chrome was closed, it catches up on the next launch. You need to be logged in to Instagram for it to work.
- **The small Instagram window:** Instagram only shows the collection list in a tab you can actually see, so the extension reads it in a small window that scrolls your Saved page and closes itself after a few seconds. The list is remembered. The window only comes back when you've made a new collection, once a week as a refresh, or when you press **Full re-check**. Downloads run in a hidden background tab, which also closes when the sync ends.
- Your username is detected automatically on the first sync. If detection fails, enter it under **Settings & history**.
- The badge on the icon shows how many new posts the last sync downloaded, or `!` if something went wrong.

## How it avoids re-downloading

- Every downloaded post is recorded in the extension's storage by its Instagram ID. A recorded post is never downloaded again.
- Instagram lists saved posts newest first. After a collection has been read in full once, later syncs stop as soon as they reach a page with nothing new. A daily sync usually takes only a few seconds.
- If a download fails, that post is retried on the next sync.
- **First collection only:** a post that's in several collections is saved once, in the first collection Instagram lists (the order in your Saved screen at the time of the sync).
- If a post that was downloaded to `Unsorted` is later added to a collection, the next sync moves it into that collection's folder and deletes the Unsorted copy.

## Settings & history (in the popup)

| Button | What it does |
| --- | --- |
| Folder inside Downloads | Change `Instagram Saved` to another folder name. Chrome only allows extensions to save inside your Downloads folder. |
| Full re-check | Reads every page of every collection instead of stopping early. Already-downloaded posts are still skipped. Use it if you think something was missed. |
| Export history | Saves the list of downloaded posts to a JSON file. |
| Import history | Loads that file back in, for example after reinstalling the extension, so nothing is downloaded twice. |
| Reset history | Forgets everything. The next sync downloads all posts again. Files already on disk are overwritten, not duplicated. |

**Back up your history:** removing the extension deletes its storage. Use **Export history** now and then.

## Tips

- If Chrome asks where to save each file, turn off *Settings → Downloads → Ask where to save each file before downloading*.
- The first sync of a large library can take a while, because the extension paces its requests (about 1–3 seconds apart) to stay gentle on Instagram. You can press **Stop** at any time. Progress is kept, and the next sync picks up where it left off.

## Caveats

- This uses the same internal web API that instagram.com itself uses. Instagram doesn't officially support it, and it may change. If syncs start failing with errors, the API probably changed.
- Automated downloading is against Instagram's Terms of Use. The pacing keeps the risk low, but it isn't zero.
- Only photos and videos are downloaded (no captions or comments).

## Files

- `manifest.json`: extension config (Manifest V3)
- `background.js`: sync engine, download tracking, daily schedule
- `popup.html` / `popup.css` / `popup.js`: the popup UI
- `icons/`: extension icons
